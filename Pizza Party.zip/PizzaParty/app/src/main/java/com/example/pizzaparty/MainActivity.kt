package com.example.pizzaparty

import android.os.Bundle
import android.view.View
import android.widget.EditText
import android.widget.RadioGroup
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import kotlin.math.ceil

const val SLICES_PER_PIZZA = 8

/**
 * This is the main activity for the pizza party app. It takes
 * input from the user on the number of people and how hungry people
 * are in order to recommend a number of pizzas when the calculate
 * button is pressed
 * @constructor creates an empty activity
 * @property numAttendEditText lets user input the number of people in the party
 * @property numPizzasTextView displays how many pizzas are needed
 * @property howHungryRadioGroup displays buttons prompting the user to enter
 * how hungry the people at the party are
 */
class MainActivity : AppCompatActivity() {

    private lateinit var numAttendEditText: EditText
    private lateinit var numPizzasTextView: TextView
    private lateinit var howHungryRadioGroup: RadioGroup

    /**
     * This function is called when the activity is created and it
     * assigns the main activities properties to the views described
     * in the xml file
     */
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        numAttendEditText = findViewById(R.id.num_attend_edit_text)
        numPizzasTextView = findViewById(R.id.num_pizzas_text_view)
        howHungryRadioGroup = findViewById(R.id.hungry_radio_group)
    }

    /**
     * Gets the inputted number of people and calculates the needed number of pizzas
     * needed based on how hungry everyone is. It then updates the displayed pizza number
     * with the new one.
     */
    fun calculateClick(view : View) {

        // Get the text that was typed into the EditText
        val numAttendStr = numAttendEditText.text.toString()

        // Convert the text into an integer
        val numAttend = numAttendStr.toInt()

        // Determine how many slices on average each person will eat
        val slicesPerPerson = when (howHungryRadioGroup.checkedRadioButtonId) {
            R.id.light_radio_button -> 2
            R.id.medium_radio_button -> 3
            else -> 4
        }

        // Calculate and show the number of pizzas needed
        val totalPizzas = ceil(numAttend * slicesPerPerson / SLICES_PER_PIZZA.toDouble()).toInt()
        numPizzasTextView.text = "Total pizzas: $totalPizzas"
    }
}